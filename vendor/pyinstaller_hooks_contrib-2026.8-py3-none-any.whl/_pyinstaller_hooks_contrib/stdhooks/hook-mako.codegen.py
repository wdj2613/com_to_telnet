# ------------------------------------------------------------------
# Copyright (c) 2020 PyInstaller Development Team.
#
# This file is distributed under the terms of the GNU General Public
# License (version 2.0 or later).
#
# The full license is available in LICENSE, distributed with
# this software.
#
# SPDX-License-Identifier: GPL-2.0-or-later
# ------------------------------------------------------------------
"""
codegen generates Python code that is then executed through exec().
This Python code imports the following modules.
"""

hiddenimports = ['mako.cache', 'mako.runtime', 'mako.filters']
